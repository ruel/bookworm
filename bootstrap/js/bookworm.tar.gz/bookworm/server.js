/*
 * server.js
 */

// Needed packages/modules
var express = require('express');
var consolidate = require('consolidate');
var swig = require('swig');
var http = require('http');

// Our very own bookworm api wrapper module
// Sort of.
var bookworm = require('./bookworm');

// app callback for http
var app = express();

// Swig initialization
app.engine('.html', consolidate.swig);
app.set('view-engine', 'html');

// Real swig initialization
swig.init({
    root        :   __dirname + '/views',
    allowErrors :   true
});
app.set('views', __dirname + '/views');

app.get('/', function(request, response) {
    bookworm.get('/books', {}, function(books) {
        response.render('index.html', { books : books });
    });
});

// Static files
app.use('/js', express.static(__dirname + '/bootstrap/js'));
app.use('/img', express.static(__dirname + '/bootstrap/img'));
app.use('/css', express.static(__dirname + '/bootstrap/css'));

// Listen to a random port (proxied)
app.listen(1338);

// Lower priveleges
process.setgid('www-data');
process.setuid('www-data');
