/*
 * bookworm.js
 */

// Needed for the client
var http = require('http');

function get(path, params, callback) {

    // Options
    var opts = {
        hostname    :   'node.ruel.me',
        port        :   80,
        path        :   path,
        method      :   'GET',
        query       :   params
    };

    // Request object
    var request = http.request(opts, function(response) {
        var books = "";

        // If ever data is chunked
        response.on('data', function(data) {
            books += data.toString();
        });

        // Last segment
        response.on('end', function() {
            callback(JSON.parse(books));
        });
    });

    // End the request
    request.end();
}

// Export functions on our module
exports.get = get;
